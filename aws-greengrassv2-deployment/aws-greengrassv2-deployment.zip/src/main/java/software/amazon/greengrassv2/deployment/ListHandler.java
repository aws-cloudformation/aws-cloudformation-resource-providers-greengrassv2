package software.amazon.greengrassv2.deployment;

import software.amazon.awssdk.services.greengrassv2.model.ListDeploymentsRequest;
import software.amazon.awssdk.services.greengrassv2.model.ListDeploymentsResponse;
import software.amazon.cloudformation.proxy.AmazonWebServicesClientProxy;
import software.amazon.cloudformation.proxy.Logger;
import software.amazon.cloudformation.proxy.OperationStatus;
import software.amazon.cloudformation.proxy.ProgressEvent;
import software.amazon.cloudformation.proxy.ResourceHandlerRequest;

// TODO: CFN does not have corresponding operations for using ListHandler yet. We need to revisit here in future.
public class ListHandler extends BaseHandler<CallbackContext> {

    @Override
    public ProgressEvent<ResourceModel, CallbackContext> handleRequest(
            final AmazonWebServicesClientProxy proxy,
            final ResourceHandlerRequest<ResourceModel> request,
            final CallbackContext callbackContext,
            final Logger logger) {

        final ResourceModel desiredResourceModel = request.getDesiredResourceState();
        logger.log("ListHandler, the desired state is:" + desiredResourceModel.toString());

        final ListDeploymentsRequest listDeploymentsRequest =
                Translator.translateToListRequest(request.getDesiredResourceState(), request.getNextToken());

        ListDeploymentsResponse listDeploymentsResponse =
                proxy.injectCredentialsAndInvokeV2(listDeploymentsRequest, ClientBuilder.getClient()::listDeployments);

        return ProgressEvent.<ResourceModel, CallbackContext>builder()
                .resourceModels(Translator.translateFromListResponse(listDeploymentsResponse))
                .nextToken(listDeploymentsResponse.nextToken())
                .status(OperationStatus.SUCCESS)
                .build();
    }
}
