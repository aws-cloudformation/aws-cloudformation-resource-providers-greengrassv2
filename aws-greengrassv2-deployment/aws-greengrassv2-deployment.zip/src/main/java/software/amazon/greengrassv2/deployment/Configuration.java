package software.amazon.greengrassv2.deployment;

import java.util.Map;

class Configuration extends BaseConfiguration {

    public Configuration() {
        super("aws-greengrassv2-deployment.json");
    }

    @Override
    public Map<String, String> resourceDefinedTags(ResourceModel resourceModel) {
        return resourceModel.getTags();
    }
}
