package software.amazon.greengrassv2.deployment;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import software.amazon.awssdk.services.greengrassv2.GreengrassV2Client;
import software.amazon.cloudformation.exceptions.CfnInvalidRequestException;
import software.amazon.cloudformation.exceptions.CfnNotUpdatableException;
import software.amazon.cloudformation.proxy.AmazonWebServicesClientProxy;
import software.amazon.cloudformation.proxy.HandlerErrorCode;
import software.amazon.cloudformation.proxy.Logger;
import software.amazon.cloudformation.proxy.ProgressEvent;
import software.amazon.cloudformation.proxy.ProxyClient;
import software.amazon.cloudformation.proxy.ResourceHandlerRequest;

import java.util.Map;
import java.util.Objects;

public class UpdateHandler extends BaseHandlerStd {
    private Logger logger;

    protected ProgressEvent<ResourceModel, CallbackContext> handleRequest(
        final AmazonWebServicesClientProxy proxy,
        final ResourceHandlerRequest<ResourceModel> request,
        final CallbackContext callbackContext,
        final ProxyClient<GreengrassV2Client> proxyClient,
        final Logger logger) {

        this.logger = logger;

        logger.log("UpdateHandler, the desired state is:" + request.getDesiredResourceState().toString());
        logger.log("UpdateHandler, the previous state is:" + request.getPreviousResourceState().toString());
        logger.log("UpdateHandler, the desired tags is:" + request.getDesiredResourceTags());
        logger.log("UpdateHandler, the previous tags is:" + request.getPreviousResourceTags());

        return ProgressEvent.progress(request.getDesiredResourceState(), callbackContext)
                .then(this::validateDeploymentIdPresent)
                .then(progressEvent -> validateCreateOnlyPropertiesNotChanged(
                        request.getDesiredResourceState(), request.getPreviousResourceState(), progressEvent))
                .then(progress -> updateTags(proxy, proxyClient, request.getDesiredResourceState().getDeploymentId(),
                        request.getDesiredResourceTags(), request.getPreviousResourceTags(), progress))
                .then(progress -> new ReadHandler().handleRequest(proxy, request, callbackContext, proxyClient, logger));
    }

    private ProgressEvent<ResourceModel, CallbackContext> validateCreateOnlyPropertiesNotChanged(
            ResourceModel desiredResourceState,
            ResourceModel previousResourceState,
            ProgressEvent<ResourceModel, CallbackContext> progressEvent) {

        if (!Objects.equals(desiredResourceState.getTargetArn(), previousResourceState.getTargetArn())) {
            return ProgressEvent.failed(previousResourceState, progressEvent.getCallbackContext(),
                    HandlerErrorCode.NotUpdatable, "TargetArn property cannot be updated.");
        }

        if (!Objects.equals(desiredResourceState.getComponents(), previousResourceState.getComponents())) {
            return ProgressEvent.failed(previousResourceState, progressEvent.getCallbackContext(),
                    HandlerErrorCode.NotUpdatable, "Component property cannot be updated.");
        }

        if (!Objects.equals(desiredResourceState.getIotJobConfiguration(), previousResourceState.getIotJobConfiguration())) {
            return ProgressEvent.failed(previousResourceState, progressEvent.getCallbackContext(),
                    HandlerErrorCode.NotUpdatable, "IotJobConfiguration property cannot be updated.");
        }

        if (!Objects.equals(desiredResourceState.getDeploymentName(), previousResourceState.getDeploymentName())) {
            return ProgressEvent.failed(previousResourceState, progressEvent.getCallbackContext(),
                    HandlerErrorCode.NotUpdatable, "DeploymentName property cannot be updated.");
        }

        if (!Objects.equals(desiredResourceState.getDeploymentPolicies(), previousResourceState.getDeploymentPolicies())) {
            return ProgressEvent.failed(previousResourceState, progressEvent.getCallbackContext(),
                    HandlerErrorCode.NotUpdatable, "DeploymentPolicies property cannot be updated.");
        }

        return progressEvent;
    }

    private ProgressEvent<ResourceModel, CallbackContext> updateTags(
            AmazonWebServicesClientProxy proxy,
            ProxyClient<GreengrassV2Client> proxyClient,
            String deploymentId,
            Map<String, String> desiredResourceTags,
            Map<String, String> previousResourceTags,
            ProgressEvent<ResourceModel, CallbackContext> progress) {

        final MapDifference<String, String> difference = Maps.difference(desiredResourceTags, previousResourceTags);
        final Map<String, String> tagsToAdd = difference.entriesOnlyOnLeft();
        final Map<String, String> tagsToRemove = difference.entriesOnlyOnRight();

        return progress
                .then(progressEvent -> {
                    if (!tagsToAdd.isEmpty()) {
                        return proxy.initiate("AWS-GreengrassV2-ComponentVersion::Update::AddTags", proxyClient, progressEvent.getResourceModel(), progress.getCallbackContext())
                                .translateToServiceRequest(model -> Translator.translateToTagResourceRequest(model.getDeploymentId(), tagsToAdd))
                                .makeServiceCall((awsRequest, client) -> {
                                    try {
                                        return client.injectCredentialsAndInvokeV2(awsRequest, client.client()::tagResource);
                                    } catch (Exception ex) {
                                        throw ExceptionTranslator.translateToCfnExceptionForCreatedResource("TagResource", deploymentId, ex);
                                    }
                                })
                                .progress();
                    } else {
                        return progress;
                    }
                })
                .then(progressEvent ->{
                    if (!tagsToRemove.isEmpty()) {
                        return proxy.initiate("AWS-GreengrassV2-ComponentVersion::Update::RemoveTags", proxyClient, progressEvent.getResourceModel(), progress.getCallbackContext())
                                .translateToServiceRequest(model -> Translator.translateToUntagResourceRequest(model.getDeploymentId(), tagsToRemove))
                                .makeServiceCall((awsRequest, client) -> {
                                    try {
                                        return client.injectCredentialsAndInvokeV2(awsRequest, client.client()::untagResource);
                                    } catch (Exception ex) {
                                        throw ExceptionTranslator.translateToCfnExceptionForCreatedResource("UntagResource", deploymentId, ex);
                                    }
                                })
                                .progress();
                    } else {
                        return progress;
                    }
                });
    }
}
