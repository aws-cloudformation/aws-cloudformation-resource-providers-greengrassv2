package software.amazon.greengrassv2.deployment;

import software.amazon.awssdk.services.greengrassv2.GreengrassV2Client;
import software.amazon.cloudformation.LambdaWrapper;

import java.net.URI;

public class ClientBuilder {
  public static GreengrassV2Client getClient() {
    return GreengrassV2Client.builder()
            .httpClient(LambdaWrapper.HTTP_CLIENT)
            .endpointOverride(URI.create("https://greengrass-beta2.us-east-1.amazonaws.com"))
            .build();
  }
}
