package software.amazon.greengrassv2.deployment;

import software.amazon.awssdk.services.greengrassv2.GreengrassV2Client;
import software.amazon.awssdk.services.greengrassv2.model.CancelDeploymentRequest;
import software.amazon.awssdk.services.greengrassv2.model.CancelDeploymentResponse;
import software.amazon.cloudformation.exceptions.CfnInvalidRequestException;
import software.amazon.cloudformation.proxy.AmazonWebServicesClientProxy;
import software.amazon.cloudformation.proxy.HandlerErrorCode;
import software.amazon.cloudformation.proxy.Logger;
import software.amazon.cloudformation.proxy.ProgressEvent;
import software.amazon.cloudformation.proxy.ProxyClient;
import software.amazon.cloudformation.proxy.ResourceHandlerRequest;

// FIXME: Right now, it just fails the request since we do not have a delete deployment API available yet.
//  And we cannot return success if the resource is not deleted. Need to fix here once that API is ready.
public class DeleteHandler extends BaseHandlerStd {
    private Logger logger;

    protected ProgressEvent<ResourceModel, CallbackContext> handleRequest(
            final AmazonWebServicesClientProxy proxy,
            final ResourceHandlerRequest<ResourceModel> request,
            final CallbackContext callbackContext,
            final ProxyClient<GreengrassV2Client> proxyClient,
            final Logger logger) {

        this.logger = logger;

        logger.log("DeleteHandler, the model is:" + request.getDesiredResourceState().toString());

        return ProgressEvent.progress(request.getDesiredResourceState(), callbackContext)
                .then(progress ->
                        proxy.initiate("AWS-GreengrassV2-Deployment::Delete", proxyClient, progress.getResourceModel(), progress.getCallbackContext())
                                .translateToServiceRequest(Translator::translateToDeleteRequest)
                                .makeServiceCall(this::cancelDeployment)
                                .progress())
                .then(progress -> ProgressEvent.defaultFailureHandler(
                        new CfnInvalidRequestException("GreengrassV2 does not support deployment deletion right now. Please change the DeletionPolicy to Retain in order to remove the stack."),
                        HandlerErrorCode.InvalidRequest));
    }

    // TODO: Just a placeholder now, should be implemented once there is an API for deleting deployment.
    private CancelDeploymentResponse cancelDeployment(final CancelDeploymentRequest request, final ProxyClient<GreengrassV2Client> client) {
        return CancelDeploymentResponse.builder().build();
    }
}
