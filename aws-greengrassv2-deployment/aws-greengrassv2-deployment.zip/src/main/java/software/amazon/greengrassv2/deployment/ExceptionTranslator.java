package software.amazon.greengrassv2.deployment;

import software.amazon.awssdk.services.greengrassv2.model.AccessDeniedException;
import software.amazon.awssdk.services.greengrassv2.model.ConflictException;
import software.amazon.awssdk.services.greengrassv2.model.InternalServerException;
import software.amazon.awssdk.services.greengrassv2.model.ResourceNotFoundException;
import software.amazon.awssdk.services.greengrassv2.model.ThrottlingException;
import software.amazon.awssdk.services.greengrassv2.model.ValidationException;
import software.amazon.cloudformation.exceptions.BaseHandlerException;
import software.amazon.cloudformation.exceptions.CfnAccessDeniedException;
import software.amazon.cloudformation.exceptions.CfnGeneralServiceException;
import software.amazon.cloudformation.exceptions.CfnInvalidRequestException;
import software.amazon.cloudformation.exceptions.CfnNotFoundException;
import software.amazon.cloudformation.exceptions.CfnResourceConflictException;
import software.amazon.cloudformation.exceptions.CfnServiceInternalErrorException;

public class ExceptionTranslator {

    public static BaseHandlerException translateToCfnExceptionForCreatedResource(String operationName,
                                                                                 String resourceIdentifier,
                                                                                 final Exception ex) {
        if (ex instanceof ResourceNotFoundException) {
            return new CfnNotFoundException(ResourceModel.TYPE_NAME, resourceIdentifier, ex);
        } else if(ex instanceof ConflictException) {
            return new CfnResourceConflictException(ResourceModel.TYPE_NAME, operationName, resourceIdentifier, ex);
        }
        return translateToCfnException(operationName, ex);
    }

    public static BaseHandlerException translateToCfnException(
            final String operationName,
            final Throwable exception) {
        if (exception instanceof ResourceNotFoundException) {
            return new CfnNotFoundException(operationName, exception.getMessage());
        }
        if (exception instanceof ValidationException) {
            return new CfnInvalidRequestException(operationName, exception);
        }
        if (exception instanceof AccessDeniedException) {
            return new CfnAccessDeniedException(operationName, exception);
        }
        if (exception instanceof InternalServerException) {
            return new CfnServiceInternalErrorException(operationName, exception);
        }
        if (exception instanceof ThrottlingException) {
            return new CfnResourceConflictException(exception);
        }
        return new CfnGeneralServiceException(exception.getMessage(), exception);
    }
}
